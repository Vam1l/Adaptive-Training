# Copilot import task

You are integrating two user-supplied overlay packages into `Vam1l/Adaptive-Training`:

- `PR1/` — adaptive domain foundation, validation, additive persistence schema/migration, architecture/privacy/roadmap docs.
- `PR2/` — deterministic exercise progression engine, tests, rationale explanation utility, and a minimal recommendation demo screen.

## Required workflow

1. Treat the packages as source overlays, not as authoritative replacements for the upstream Ischys chassis.
2. Start from the latest appropriate Ischys source and preserve its MIT `LICENSE` and `NOTICE` obligations.
3. Merge PR1 first, then PR2.
4. Preserve the richer upstream Expo/React Native package configuration. Do not blindly overwrite `package.json`, `tsconfig.json`, app identifiers, native targets, HealthKit files, or Apple Watch targets with overlay versions.
5. Reconcile import paths and schema conventions to the actual Ischys source tree.
6. Keep the recommendation engine in a pure TypeScript domain layer with no React Native, HealthKit, network, or AI dependency.
7. Do not add proprietary EvolveAI code, branding, UI, or trade secrets.
8. Do not commit secrets, `.env` files, personal data, Garmin exports, HealthKit exports, or workout databases.
9. Run typecheck, tests, configured lint, and secret scanning.
10. Review the deterministic PR2 rules for correctness. Keep them conservative; do not introduce readiness, Garmin, HealthKit recovery, multi-sport fatigue, or full mesocycle logic yet.
11. If repository push is unavailable, preserve the integrated repository as a downloadable artifact before the environment ends.

## Desired result

Create branch `feat/adaptive-engine-foundation` and integrate both packages into the Ischys-based app. The app should retain the existing workout logger and native integrations while gaining the adaptive domain model and deterministic progression engine.

Return changed files, test results, unresolved conflicts, and any native iOS/Expo concerns.
