# Manual integration

1. Apply/import the PR1 package first.
2. Merge the files in this package into the same repository, preserving existing project configuration where conflicts occur.
3. Do not replace a richer upstream `package.json` with a minimal package from an overlay.
4. Run typecheck and unit tests.
5. Have Copilot review the engine rules for consistency with the app's existing data model before wiring them into production workout flows.

The engine is intentionally conservative and deterministic. It does not use AI, Garmin APIs, or HealthKit recovery data yet.
