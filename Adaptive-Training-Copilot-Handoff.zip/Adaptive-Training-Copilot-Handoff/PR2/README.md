# Adaptive Training PR2 — Deterministic Recommendation Engine

This package layers on top of the PR1 Adaptive Training domain model. It adds a small, deterministic, testable progression engine and a minimal recommendation demo screen.

It is intended as an integration overlay for the Ischys-based application chassis, not as a replacement for the full upstream app.
