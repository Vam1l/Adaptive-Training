# Manual upload instructions

This archive is designed to be uploaded into the root of the `Adaptive-Training` repository.

## GitHub web/mobile approach

1. Extract the ZIP locally.
2. Add the extracted files/folders to the repository, preserving paths.
3. Commit with: `Foundation: adaptive training domain model`.
4. If GitHub web cannot upload nested folders conveniently, use GitHub Desktop or a local Git client.

## Important merge note

This package contains the PR1 adaptive domain foundation and a minimal TypeScript validation harness. It does **not** contain the entire Ischys application chassis. When the Ischys chassis is imported, merge these files into its `frontend/src` tree and translate `0001_adaptive_foundation.sql` into the project's existing Drizzle migration conventions.

That separation is intentional: it avoids falsely claiming a complete upstream import when this environment cannot download the full GitHub repository archive directly.
