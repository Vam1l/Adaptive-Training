# Adaptive Training

Local-first adaptive training application foundation for iPhone/Apple Watch workflows.

This PR1 package establishes the adaptive-training domain model, validation, persistence schema additions, and architecture/privacy documentation. It intentionally does **not** implement the full recommendation engine, Garmin APIs, or AI coaching.

## Manual upload

Upload the contents of this archive to the root of `Vam1l/Adaptive-Training` (preserving folders). Then commit as:

`Foundation: adaptive training domain model`

## Validation

From `frontend/`:

```bash
npm install
npm run typecheck
npm test
```

## Design principles

- local-first data storage
- deterministic, testable recommendation logic
- objective recovery data kept separate from subjective readiness
- optional AI explanation layer later
- no credentials, raw HealthKit/Garmin exports, or personal training databases in source control
